<?php require("docgen.inc"); ?>

<?php BeginPage('cdplay', 'Sega Saturn Sound Format Player'); ?>

<?php BeginSection('Introduction', "Section_intro"); ?>
CD-DA player, for dev testing purposes mostly.
<?php EndSection(); ?>

<?php PrintSettings(); ?>

<?php EndPage(); ?>
