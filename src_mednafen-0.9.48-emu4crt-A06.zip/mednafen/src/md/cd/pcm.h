#ifndef __MDFN_MD_PCM_H
#define __MDFN_MD_PCM_H

namespace MDFN_IEN_MD
{

void MDCD_PCM_Write(uint32 A, uint8 V);
void MDCD_PCM_Reset(void);

}

#endif
