
#ifndef _MEMVDP_H_
#define _MEMVDP_H_

namespace MDFN_IEN_MD
{


/* Function prototypes */
unsigned int vdp_dma_r(unsigned int address);

}

#endif /* _MEMVDP_H_ */
