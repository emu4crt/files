
void MDFNI_SelectMovie(int);

void MDFNI_SaveMovie(char *fname, const MDFN_Surface *surface, const MDFN_Rect *DisplayRect, const int32 *LineWidths);
void MDFNI_LoadMovie(char *fname);

