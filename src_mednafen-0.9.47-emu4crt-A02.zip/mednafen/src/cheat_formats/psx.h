#ifndef __MDFN_CHEAT_FORMATS_PSX_H
#define __MDFN_CHEAT_FORMATS_PSX_H

extern const std::vector<CheatFormatStruct> CheatFormats_PSX;

#endif
