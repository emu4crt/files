namespace MDFN_IEN_GBA
{

unsigned int RunARM(void);

}
