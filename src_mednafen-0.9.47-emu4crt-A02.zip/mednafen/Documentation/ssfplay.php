<?php require("docgen.inc"); ?>

<?php BeginPage('ssfplay', 'Sega Saturn Sound Format Player'); ?>

<?php BeginSection('Introduction', "Section_intro"); ?>
Sega Saturn Sound Format (ripped music format in the PSF family) player.
<?php EndSection(); ?>

<?php PrintSettings(); ?>

<?php EndPage(); ?>
