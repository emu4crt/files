#ifndef __MD_MAP_SVP_H
#define __MD_MAP_SVP_H

MD_Cart_Type *MD_Make_Cart_Type_SVP(const md_game_info *ginfo, const uint8 *ROM, const uint32 ROM_size, const uint32 iparam, const char *sparam);

#endif
