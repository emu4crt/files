namespace MDFN_IEN_GBA
{

unsigned int RunTHUMB(void);

}
