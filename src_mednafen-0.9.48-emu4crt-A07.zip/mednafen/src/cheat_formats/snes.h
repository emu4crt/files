#ifndef __MDFN_CHEAT_FORMATS_SNES_H
#define __MDFN_CHEAT_FORMATS_SNES_H

extern const std::vector<CheatFormatStruct> CheatFormats_SNES;

#endif
