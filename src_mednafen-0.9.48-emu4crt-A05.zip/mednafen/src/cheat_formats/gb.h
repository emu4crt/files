#ifndef __MDFN_CHEAT_FORMATS_GB_H
#define __MDFN_CHEAT_FORMATS_GB_H

extern const std::vector<CheatFormatStruct> CheatFormats_GB;

#endif
