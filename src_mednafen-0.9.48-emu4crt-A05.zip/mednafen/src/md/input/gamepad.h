namespace MDFN_IEN_MD
{

extern const IDIISG Gamepad2IDII;
extern const IDIISG GamepadIDII;
extern const IDIISG Gamepad6IDII;
MD_Input_Device *MDInput_MakeMS2B(void);
MD_Input_Device *MDInput_MakeMD3B(void);
MD_Input_Device *MDInput_MakeMD6B(void);

}
