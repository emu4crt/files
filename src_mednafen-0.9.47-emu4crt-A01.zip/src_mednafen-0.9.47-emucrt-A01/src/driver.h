#ifndef __MDFN_DRIVER_H
#define __MDFN_DRIVER_H

#include "mednafen.h"
#include "settings-driver.h"
#include "mednafen-driver.h"
#include "netplay-driver.h"
#include "state-driver.h"
#include "movie-driver.h"
#include "mempatcher-driver.h"
#include "video-driver.h"

#endif
